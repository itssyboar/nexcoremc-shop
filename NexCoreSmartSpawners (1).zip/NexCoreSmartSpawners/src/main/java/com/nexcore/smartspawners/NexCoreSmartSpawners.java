package com.nexcore.smartspawners;

import com.nexcore.smartspawners.config.SpawnerCatalog;
import com.nexcore.smartspawners.gui.SmartSpawnerShopGUI;
import com.nexcore.smartspawners.integration.MainShopIntegration;
import com.nexcore.smartspawners.listeners.MainShopInjectListener;
import com.nexcore.smartspawners.listeners.SpawnerShopListener;
import github.nighter.smartspawner.api.SmartSpawnerAPI;
import github.nighter.smartspawner.api.SmartSpawnerProvider;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class NexCoreSmartSpawners extends JavaPlugin {

    private Economy economy;
    private SmartSpawnerAPI smartSpawnerAPI;
    private SpawnerCatalog spawnerCatalog;
    private MainShopIntegration mainShopIntegration;
    private SmartSpawnerShopGUI shopGUI;
    private PurchaseService purchaseService;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        if (!setupSmartSpawner()) {
            getLogger().severe("SmartSpawner was not found or is not enabled! This plugin requires SmartSpawner 1.5.8+.");
            getLogger().severe("Plugin will be disabled.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        if (!setupEconomy()) {
            getLogger().severe("Vault (with an economy plugin) was not found! This plugin requires Vault.");
            getLogger().severe("Plugin will be disabled.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.spawnerCatalog = SpawnerCatalog.load(this);
        this.mainShopIntegration = new MainShopIntegration(this);
        this.shopGUI = new SmartSpawnerShopGUI(this);
        this.purchaseService = new PurchaseService(this);

        getServer().getPluginManager().registerEvents(new MainShopInjectListener(this), this);
        getServer().getPluginManager().registerEvents(new SpawnerShopListener(this), this);

        var command = getCommand("smartspawnershop");
        if (command != null) {
            command.setExecutor(new SmartSpawnerShopCommand(this));
        }

        if (mainShopIntegration.getDonutShop() == null) {
            getLogger().warning("CredosShop (DonutShop) was not found. The Smart Spawners button will not be "
                    + "injected into any menu until it is installed and enabled, but /smartspawnershop still works.");
        }

        getLogger().info("NexCoreSmartSpawners has been enabled with " + spawnerCatalog.getEntries().size()
                + " spawner types configured.");
    }

    @Override
    public void onDisable() {
        getLogger().info("NexCoreSmartSpawners has been disabled.");
    }

    private boolean setupSmartSpawner() {
        if (getServer().getPluginManager().getPlugin("SmartSpawner") == null) {
            return false;
        }
        this.smartSpawnerAPI = SmartSpawnerProvider.getAPI();
        return this.smartSpawnerAPI != null;
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> provider = getServer().getServicesManager().getRegistration(Economy.class);
        if (provider == null) {
            return false;
        }
        this.economy = provider.getProvider();
        return this.economy != null;
    }

    public Economy getEconomy() {
        return economy;
    }

    public SmartSpawnerAPI getSmartSpawnerAPI() {
        return smartSpawnerAPI;
    }

    public SpawnerCatalog getSpawnerCatalog() {
        return spawnerCatalog;
    }

    public MainShopIntegration getMainShopIntegration() {
        return mainShopIntegration;
    }

    public SmartSpawnerShopGUI getShopGUI() {
        return shopGUI;
    }

    public PurchaseService getPurchaseService() {
        return purchaseService;
    }

    public int getMainShopSlot() {
        return mainShopIntegration.getMainMenuSlot();
    }
}
