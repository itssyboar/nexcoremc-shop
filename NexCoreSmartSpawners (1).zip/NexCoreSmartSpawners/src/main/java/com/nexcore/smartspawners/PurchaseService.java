package com.nexcore.smartspawners;

import com.nexcore.smartspawners.config.SpawnerEntry;
import com.nexcore.smartspawners.util.TextFormatter;
import github.nighter.smartspawner.api.SmartSpawnerAPI;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles the actual buy transaction. Every purchase goes through, in this
 * strict order, so nothing can be charged without a matching item, or given
 * without a matching charge:
 *   1. reject if this player already has a purchase in flight (double-click /
 *      double-event guard)
 *   2. check balance
 *   3. check inventory has room BEFORE taking any money
 *   4. withdraw funds
 *   5. hand over the real SmartSpawner item
 *   6. (defensive) if it somehow didn't fit after all, drop it at the
 *      player's feet instead of losing it, since money was already taken
 */
public final class PurchaseService {

    private final NexCoreSmartSpawners plugin;
    private final Set<UUID> processing = ConcurrentHashMap.newKeySet();

    public PurchaseService(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    public void purchase(Player player, SpawnerEntry entry) {
        if (!processing.add(player.getUniqueId())) {
            // A previous click from this player for this or another spawner
            // has not finished processing yet - ignore this one rather than
            // risk a double charge / double item.
            player.sendMessage(TextFormatter.colorize(
                    plugin.getConfig().getString("messages.already-processing",
                            "&cPlease wait, your last purchase is still processing.")));
            return;
        }

        try {
            processPurchase(player, entry);
        } finally {
            processing.remove(player.getUniqueId());
        }
    }

    private void processPurchase(Player player, SpawnerEntry entry) {
        Economy economy = plugin.getEconomy();
        double price = entry.getPrice();

        if (economy.getBalance(player) < price) {
            fail(player, plugin.getConfig().getString("messages.not-enough-money", "&cYou don't have enough money."));
            return;
        }

        if (!hasInventorySpace(player, Material.SPAWNER, 1)) {
            fail(player, plugin.getConfig().getString("messages.inventory-full", "&cYour inventory is full."));
            return;
        }

        // Charge only after both checks above have already passed.
        economy.withdrawPlayer(player, price);

        SmartSpawnerAPI api = plugin.getSmartSpawnerAPI();
        ItemStack spawnerItem = api.createSpawnerItem(entry.getEntityType(), 1);

        HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(spawnerItem);
        if (!leftover.isEmpty()) {
            // Should not normally happen since we pre-checked space above,
            // but if some other plugin/event changed the inventory in the
            // meantime, don't silently delete an item the player already
            // paid for - drop it at their feet instead.
            Location loc = player.getLocation();
            for (ItemStack stack : leftover.values()) {
                player.getWorld().dropItemNaturally(loc, stack);
            }
        }

        String successMessage = plugin.getConfig().getString("messages.purchase-success",
                        "&aYou purchased a &f%spawner%&a for &f$%price%&a!")
                .replace("%spawner%", TextFormatter.colorize(entry.getDisplayName()))
                .replace("%price%", String.valueOf((long) price));
        player.sendMessage(TextFormatter.colorize(successMessage));
        playSound(player, "purchase-successful");
    }

    private void fail(Player player, String message) {
        player.sendMessage(TextFormatter.colorize(message));
        playSound(player, "purchase-unsuccessful");
    }

    private void playSound(Player player, String key) {
        String soundName = plugin.getConfig().getString("sounds." + key, "");
        if (soundName.isEmpty()) {
            return;
        }
        try {
            Sound sound = Sound.valueOf(soundName);
            float volume = (float) plugin.getConfig().getDouble("sounds." + key + "-volume", 0.5);
            player.playSound(player.getLocation(), sound, volume, 1.0f);
        } catch (IllegalArgumentException ignored) {
            // Unknown sound name in config.yml - fail silently rather than break the purchase.
        }
    }

    /**
     * Same capacity-counting approach as DonutShop's own hasInventorySpace
     * helper: walk the player's storage contents, subtract remaining
     * capacity per slot, and check whether at least `amount` more items of
     * `material` would fit.
     */
    private boolean hasInventorySpace(Player player, Material material, int amount) {
        int maxStackSize = material.getMaxStackSize();
        int remaining = amount;

        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack == null || stack.getType() == Material.AIR) {
                remaining -= maxStackSize;
            } else if (stack.getType() == material) {
                remaining -= (maxStackSize - stack.getAmount());
            }
            if (remaining <= 0) {
                return true;
            }
        }
        return remaining <= 0;
    }
}
