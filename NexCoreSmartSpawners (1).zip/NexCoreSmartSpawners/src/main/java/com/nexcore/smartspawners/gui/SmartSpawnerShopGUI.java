package com.nexcore.smartspawners.gui;

import com.nexcore.smartspawners.NexCoreSmartSpawners;
import com.nexcore.smartspawners.config.SpawnerEntry;
import com.nexcore.smartspawners.util.TextFormatter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SmartSpawnerShopGUI {

    public static final int SIZE = 27;
    public static final int BACK_SLOT = 18;

    private final NexCoreSmartSpawners plugin;

    public SmartSpawnerShopGUI(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = TextFormatter.colorize(
                plugin.getConfig().getString("gui.shop-title", "ѕʜᴏᴘ - ѕᴍᴀʀᴛ ѕᴘᴀᴡɴᴇʀs"));

        SmartSpawnerShopHolder holder = new SmartSpawnerShopHolder(player);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, title);
        holder.setInventory(inventory);

        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, createPlaceholder());
        }

        for (SpawnerEntry entry : plugin.getSpawnerCatalog().getEntries()) {
            inventory.setItem(entry.getSlot(), createSpawnerIcon(entry));
        }

        inventory.setItem(BACK_SLOT, createBackButton());

        player.openInventory(inventory);
    }

    private ItemStack createSpawnerIcon(SpawnerEntry entry) {
        ItemStack item = new ItemStack(entry.getIcon());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextFormatter.colorize(entry.getDisplayName()));

            List<String> lore = new ArrayList<>();
            lore.add(TextFormatter.colorize("&fPrice: &a$" + formatNumber(entry.getPrice())));
            lore.add(TextFormatter.colorize("&fClick to purchase"));
            meta.setLore(lore);

            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createBackButton() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextFormatter.colorize(
                    plugin.getConfig().getString("gui.back-button-name", "<#fd0100>ʙᴀᴄᴋ")));
            meta.setLore(TextFormatter.colorize(
                    plugin.getConfig().getStringList("gui.back-button-lore")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createPlaceholder() {
        ItemStack item = new ItemStack(Material.AIR);
        return item;
    }

    private static String formatNumber(double value) {
        return NumberFormat.getIntegerInstance(Locale.US).format((long) value);
    }
}
