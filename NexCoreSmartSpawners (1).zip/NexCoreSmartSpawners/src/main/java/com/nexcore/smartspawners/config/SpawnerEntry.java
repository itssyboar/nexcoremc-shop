package com.nexcore.smartspawners.config;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

/**
 * One row of the smart-spawners section of config.yml, resolved and
 * validated once at load time.
 */
public final class SpawnerEntry {

    private final String key;
    private final EntityType entityType;
    private final double price;
    private final Material icon;
    private final String displayName;
    private final int slot;

    public SpawnerEntry(String key, EntityType entityType, double price, Material icon, String displayName, int slot) {
        this.key = key;
        this.entityType = entityType;
        this.price = price;
        this.icon = icon;
        this.displayName = displayName;
        this.slot = slot;
    }

    public String getKey() {
        return key;
    }

    public EntityType getEntityType() {
        return entityType;
    }

    public double getPrice() {
        return price;
    }

    public Material getIcon() {
        return icon;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getSlot() {
        return slot;
    }
}
