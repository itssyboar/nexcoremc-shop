package com.nexcore.smartspawners.listeners;

import com.nexcore.smartspawners.NexCoreSmartSpawners;
import com.nexcore.smartspawners.util.TextFormatter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * DonutShop's main menu (see MainShopGUI.class in Donut_Shop.jar) is a
 * plain 27-slot inventory created with Bukkit.createInventory(null, 27,
 * title) - it has no custom InventoryHolder to hook into, and by the time
 * player.openInventory(inv) is called every slot (0-26) is already filled,
 * either with a category item (slots 11-15) or an invisible AIR
 * placeholder (everywhere else). InventoryOpenEvent fires AFTER that
 * population but before the player actually sees the inventory, so it is
 * the correct, minimally-invasive point to drop our own button into one of
 * those placeholder slots without ever touching DonutShop's own code.
 */
public final class MainShopInjectListener implements Listener {

    private final NexCoreSmartSpawners plugin;

    public MainShopInjectListener(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    // NORMAL (the default) rather than MONITOR: we are actively modifying
    // the inventory's contents here (setItem), not just observing it, and
    // MONITOR is reserved for listeners that must not change the outcome
    // of an event. HIGH would also be acceptable; NORMAL is enough since
    // DonutShop itself has already fully populated the inventory before
    // this event fires (its population happens in MainShopGUI.open(),
    // synchronously, before player.openInventory() is called - not inside
    // any event handler), so ordering relative to other plugins' opening
    // logic isn't a concern here.
    @EventHandler
    public void onOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }
        if (!isDonutShopMainMenu(event.getView().getTitle())) {
            return;
        }

        int slot = plugin.getMainShopIntegration().getMainMenuSlot();
        event.getInventory().setItem(slot, createCategoryButton());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory clickedInventory = event.getClickedInventory();
        if (clickedInventory == null || clickedInventory.equals(player.getInventory())) {
            // Mirrors DonutShop's own listener: clicks inside the player's
            // own inventory while the shop is open are none of our business.
            return;
        }

        if (!isDonutShopMainMenu(event.getView().getTitle())) {
            return;
        }

        int slot = plugin.getMainShopIntegration().getMainMenuSlot();
        if (event.getSlot() != slot) {
            return;
        }

        event.setCancelled(true);
        // Defer opening our GUI by one tick, same pattern any well-behaved
        // shop plugin uses when swapping inventories from inside a click
        // event, to avoid client-side inventory desync.
        Bukkit.getScheduler().runTask(plugin, () -> plugin.getShopGUI().open(player));
    }

    private boolean isDonutShopMainMenu(String openTitle) {
        if (plugin.getMainShopIntegration().getDonutShop() == null) {
            return false;
        }
        return openTitle.equals(plugin.getMainShopIntegration().getMainShopTitle());
    }

    private ItemStack createCategoryButton() {
        ItemStack item = new ItemStack(Material.SPAWNER);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextFormatter.colorize(
                    plugin.getConfig().getString("gui.category-button-name", "<#00F986>sᴍᴀʀᴛ sᴘᴀᴡɴᴇʀs")));
            List<String> lore = TextFormatter.colorize(plugin.getConfig().getStringList("gui.category-button-lore"));
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }
}
