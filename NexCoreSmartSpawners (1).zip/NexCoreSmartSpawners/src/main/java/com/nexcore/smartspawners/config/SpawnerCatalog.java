package com.nexcore.smartspawners.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

/**
 * Reads the "smart-spawners" section of config.yml and builds the ordered
 * list of items shown in the shop GUI. Bad entries are logged and skipped
 * rather than crashing the whole plugin, so a typo in config.yml can't take
 * the entire shop down.
 */
public final class SpawnerCatalog {

    /** First inventory slot used for spawner icons, mirroring DonutShop's own EndShopGUI/NetherShopGUI layout (items start at slot 9). */
    private static final int FIRST_ITEM_SLOT = 9;

    private final List<SpawnerEntry> entries;

    private SpawnerCatalog(List<SpawnerEntry> entries) {
        this.entries = entries;
    }

    public List<SpawnerEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public static SpawnerCatalog load(Plugin plugin) {
        Logger logger = plugin.getLogger();
        List<SpawnerEntry> entries = new ArrayList<>();

        ConfigurationSection root = plugin.getConfig().getConfigurationSection("smart-spawners");
        if (root == null) {
            logger.severe("config.yml is missing the 'smart-spawners' section - the shop will be empty.");
            return new SpawnerCatalog(entries);
        }

        int slot = FIRST_ITEM_SLOT;
        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) {
                logger.warning("smart-spawners." + key + " is not a valid section, skipping.");
                continue;
            }

            String entityTypeName = section.getString("entity-type", "").toUpperCase();
            EntityType entityType;
            try {
                entityType = EntityType.valueOf(entityTypeName);
            } catch (IllegalArgumentException ex) {
                logger.severe("smart-spawners." + key + ".entity-type '" + entityTypeName
                        + "' is not a valid Bukkit EntityType, skipping.");
                continue;
            }

            if (entityType == EntityType.PLAYER) {
                logger.severe("smart-spawners." + key + " cannot use entity-type PLAYER, skipping.");
                continue;
            }

            double price = section.getDouble("price", -1);
            if (price < 0) {
                logger.severe("smart-spawners." + key + ".price is missing or negative, skipping.");
                continue;
            }

            String iconName = section.getString("icon", "SPAWNER").toUpperCase();
            Material icon = Material.matchMaterial(iconName);
            if (icon == null) {
                logger.warning("smart-spawners." + key + ".icon '" + iconName + "' is invalid, falling back to SPAWNER.");
                icon = Material.SPAWNER;
            }

            String displayName = section.getString("display-name", key);

            if (slot > 16) {
                logger.severe("smart-spawners has more than 8 entries; entry '" + key
                        + "' does not fit in the GUI and will be skipped. Remove extra entries or edit the GUI layout.");
                continue;
            }

            entries.add(new SpawnerEntry(key, entityType, price, icon, displayName, slot));
            slot++;
        }

        return new SpawnerCatalog(entries);
    }
}
