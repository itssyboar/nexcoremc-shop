package com.nexcore.smartspawners.integration;

import com.nexcore.smartspawners.NexCoreSmartSpawners;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * All interaction with DonutShop goes through this class, and only ever
 * through the generic org.bukkit.plugin.Plugin interface (getConfig(),
 * isEnabled()) and its public "/shop" command - never through any of
 * DonutShop's own internal classes. That means:
 *  - DonutShop.jar is never touched, never decompiled/recompiled, never
 *    even a compile-time dependency of this project.
 *  - If DonutShop ever changes its internal GUI implementation, this
 *    plugin keeps working as long as the config key and command stay put.
 */
public final class MainShopIntegration {

    private final NexCoreSmartSpawners plugin;

    public MainShopIntegration(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    private String pluginName() {
        return plugin.getConfig().getString("integration.donutshop-plugin-name", "CredosShop");
    }

    public Plugin getDonutShop() {
        Plugin donutShop = Bukkit.getPluginManager().getPlugin(pluginName());
        if (donutShop == null || !donutShop.isEnabled()) {
            return null;
        }
        return donutShop;
    }

    /**
     * The exact title string DonutShop currently uses for its main menu,
     * read live from its own config.yml so the two plugins can never drift
     * out of sync even if the server owner edits DonutShop's config.
     */
    public String getMainShopTitle() {
        Plugin donutShop = getDonutShop();
        String fallback = plugin.getConfig().getString("integration.fallback-main-shop-title", "ѕʜᴏᴘ");
        if (donutShop == null) {
            return fallback;
        }
        return donutShop.getConfig().getString("gui.main-shop-title", fallback);
    }

    public int getMainMenuSlot() {
        return plugin.getConfig().getInt("integration.main-menu-slot", 16);
    }

    public void openMainShop(Player player) {
        Plugin donutShop = getDonutShop();
        if (donutShop == null) {
            player.sendMessage(com.nexcore.smartspawners.util.TextFormatter.colorize(
                    plugin.getConfig().getString("messages.donutshop-missing", "&cThe main shop is currently unavailable.")));
            return;
        }
        String command = plugin.getConfig().getString("integration.donutshop-open-command", "shop");
        player.performCommand(command.replace("/", ""));
    }
}
