package com.nexcore.smartspawners;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SmartSpawnerShopCommand implements CommandExecutor {

    private final NexCoreSmartSpawners plugin;

    public SmartSpawnerShopCommand(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }
        plugin.getShopGUI().open(player);
        return true;
    }
}
