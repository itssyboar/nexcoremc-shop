package com.nexcore.smartspawners.listeners;

import com.nexcore.smartspawners.NexCoreSmartSpawners;
import com.nexcore.smartspawners.config.SpawnerEntry;
import com.nexcore.smartspawners.gui.SmartSpawnerShopGUI;
import com.nexcore.smartspawners.gui.SmartSpawnerShopHolder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.Optional;

public final class SpawnerShopListener implements Listener {

    private final NexCoreSmartSpawners plugin;

    public SpawnerShopListener(NexCoreSmartSpawners plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory topInventory = event.getView().getTopInventory();
        InventoryHolder holder = topInventory.getHolder();
        if (!(holder instanceof SmartSpawnerShopHolder)) {
            return;
        }

        // Cancel every click anywhere in this view (our GUI or the
        // player's own inventory while it is open) so nothing can ever be
        // physically taken out of, or shift-clicked into, our shop
        // inventory - this is what stops item-duplication tricks based on
        // rapid inventory manipulation.
        event.setCancelled(true);

        Inventory clickedInventory = event.getClickedInventory();
        if (clickedInventory == null || !clickedInventory.equals(topInventory)) {
            return;
        }

        int slot = event.getSlot();

        if (slot == SmartSpawnerShopGUI.BACK_SLOT) {
            player.closeInventory();
            plugin.getMainShopIntegration().openMainShop(player);
            return;
        }

        Optional<SpawnerEntry> entry = plugin.getSpawnerCatalog().getEntries().stream()
                .filter(e -> e.getSlot() == slot)
                .findFirst();

        entry.ifPresent(spawnerEntry -> plugin.getPurchaseService().purchase(player, spawnerEntry));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        Inventory topInventory = event.getView().getTopInventory();
        if (topInventory.getHolder() instanceof SmartSpawnerShopHolder) {
            event.setCancelled(true);
        }
    }
}
