package com.nexcore.smartspawners.gui;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Unlike DonutShop's own main menu (which is a plain, holder-less inventory
 * identified only by matching its title string), our own Smart Spawners GUI
 * uses a real InventoryHolder. This lets our click/drag listeners recognise
 * "is this our inventory?" with a simple instanceof check instead of a
 * fragile title comparison, and avoids any chance of colliding with some
 * other plugin's inventory that happens to share a title.
 */
public final class SmartSpawnerShopHolder implements InventoryHolder {

    private final Player player;
    private Inventory inventory;

    public SmartSpawnerShopHolder(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return player;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
