package com.nexcore.smartspawners.util;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Small self-contained colorizer so this plugin never has to depend on
 * DonutShop's internal TextFormatter class. Supports legacy '&' codes and
 * "<#RRGGBB>" hex tags (translated into the legacy hex-color escape sequence
 * so it still works with the deprecated but still-functional
 * ItemMeta#setDisplayName(String) / #setLore(List) legacy API, exactly like
 * DonutShop itself uses).
 */
public final class TextFormatter {

    private static final Pattern HEX_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");

    private TextFormatter() {
    }

    public static String colorize(String input) {
        if (input == null) {
            return "";
        }

        Matcher matcher = HEX_PATTERN.matcher(input);
        StringBuilder buffer = new StringBuilder();

        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement.toString()));
        }
        matcher.appendTail(buffer);

        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public static List<String> colorize(List<String> input) {
        List<String> result = new ArrayList<>();
        if (input == null) {
            return result;
        }
        for (String line : input) {
            result.add(colorize(line));
        }
        return result;
    }
}
